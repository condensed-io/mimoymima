// global.js
